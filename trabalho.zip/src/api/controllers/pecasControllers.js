const { update } = require('../models/motorModels.js');
const Motor = require('../models/motorModels.js')
const Pecas = require('../models/pecasModels.js');
//const { index } = require('./indexControllers.js');

module.exports = {

    async index(req, res) {
        const { motor_id } = req.params
        console.log('Parametro empresa esperado ' + motor_id)

        const pecas = await Motor.findByPk(motor_id, {
            include: { association: 'motor' }
        })

        return res.json(pecas)

    },

    async store(req, res) {
        const { motor_id } = req.params
        const { motor_nome, motor_fabricante, motor_potencia,
            motor_cilindrada} = req.body

        console.log('Parametro esperado: ' + motor_id)
        console.log('Dados: ' + req.body)
        // validar o motor
        const motor = await Motor.findByPk(motor_id)

        if (!motor) {
            return res.status(400).json({ error: 'Motor não encontrada!' })
        }
        const pecas = await Pecas.create({
            pec_nome,
            pec_fabricante,
            pec_descricao,
            pec_datafab,
        });

        return res.json(pecas);
    },

    async update(req, res) {
        const { pecas_id } = req.params
        const { pec_nome, pec_fabricante, pec_descricao, pec_datafab } = req.body

        await Pecas.update({
            pec_nome, pec_fabricante, pec_descricao, pec_datafab
        }, {
            where: { id: pecas_id }
        });

        return res.status(200).send({
            status: 1,
            message: "Peças atualizadas com sucesso!"
        })
    },

    async delete(req, res) {
        const { funcionario_id } = req.params

        // validar funcionario
        const funcionario = await Funcionarios.findByPk(funcionario_id)

        if(Funcionario){
            return res.status(400).json({error: "Funcionario não encontrado!"})
        } else {
            console.log("Funcionario encontrado!")
        }
        await Funcionarios.destroy({
            where: {
                id: funcionario_id
            }
        })

            funcionario.fun_senha = undefined

            return res.status(200).send({
                status: 1,
                message: 'Usuário deletado com sucesso!',
                funcionario
        })

    }

};


