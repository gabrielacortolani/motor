const Empresas = require('../models/motorModels.js')

module.exports = {
    async indexAll(req, res) {
        const motor = await Motor.findAll();
        return res.json(motor)
    },

    async store(req, res) {
        const {motor_nome, motor_fabricante, motor_potencia, motor_cilindrada} = req.body
        const motor = await Motor.create({
            motor_nome,
            motor_fabricante,
            motor_potencia,
            motor_cilindrada,
        });
        return res.status(200).send({
            status: 1,
            message: 'Motor cadastrado com sucesso!!!',
            motor
        })
    }
}

