module.exports = {
    index(req, res) {
        res.send('Rota Raiz Encontrada!!!')
    }
}

