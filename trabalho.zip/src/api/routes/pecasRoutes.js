const express = require('express')
const router = express.Router();

const funcionariosControllers = require('../controllers/pecasControllers.js')

router.get('/pecas', pecasControllers.indexAll)

router.post('/motor/:motor_id/pecas', pecasControllers.store)

router.get('/motor/:motor_id/pecas', pecasControllers.index)

router.put('/motor/:motor_id/pecas', pecasControllers.update)

router.delete('/Pecas/:pecas_id', pecasControllers.delete)

module.exports = router

