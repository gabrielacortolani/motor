const express = require('express')
const router = express.Router();

const empresasControllers = require('../controllers/motorControllers.js')

router.get('/motor', motorControllers.indexAll)

router.post('/motor', motorControllers.store)


module.exports = router
