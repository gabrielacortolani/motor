module.exports = {
    host: "localhost",
    dialect: "mysql",
    username: "root",
    password: "gabi",
    database: "webIII",
    define: {
        timestamps: true,
        underscored: true,
    },
};
